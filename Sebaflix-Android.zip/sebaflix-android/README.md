# Sebaflix Android

Port nativo (Kotlin + Jetpack Compose + Media3) de Sebaflix V28 (Roku). Mismo protocolo de addons Stremio, reproduccion sin reinicios por buffering y progreso guardado solo al salir.

## Compilar el APK (sin instalar nada)
1. Crea un repo en GitHub y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Pestana **Actions** > **Build APK** > **Run workflow**.
3. Al terminar, descarga el artefacto **Sebaflix-APK** (zip con `app-debug.apk`) e instalalo.

## Local
Android Studio: abrir carpeta > Run. O `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).

## Uso
Abre **Addons** y anade la URL `https://.../manifest.json` de tus addons. Solo fuentes HTTP(S) directas (HLS/MP4/DASH).

package com.sebaflix.app

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage

val Red = Color(0xFFE50914)
val Bg = Color(0xFF080808)
val Card = Color(0xFF1A1A1A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Card)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App() }
            }
        }
    }
}

@Composable
fun App(vm: Vm = viewModel()) {
    BackHandler(vm.stack.size > 1) { vm.stack.removeAt(vm.stack.lastIndex) }
    when (val s = vm.stack.last()) {
        is Screen.Home -> HomeScreen(vm)
        is Screen.Addons -> AddonsScreen(vm)
        is Screen.Detail -> DetailScreen(vm)
        is Screen.Player -> PlayerScreen(vm, s)
    }
}

@Composable
fun Poster(item: Item, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    Column(
        Modifier.width(112.dp).onFocusChanged { f = it.isFocused }.clickable(onClick = onClick)
            .border(2.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(8.dp)).padding(2.dp)
    ) {
        AsyncImage(
            model = item.poster, contentDescription = item.name, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(6.dp)).background(Card)
        )
        Text(item.name, color = Color.White, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun MovieRow(title: String, items: List<Item>, vm: Vm) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier.padding(start = 16.dp, bottom = 6.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.id }) { i -> Poster(i) { vm.openDetail(i) } }
        }
    }
}

@Composable
fun HomeScreen(vm: Vm) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("SEBAFLIX", color = Red, fontWeight = FontWeight.Black, fontSize = 22.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.stack.add(Screen.Addons) }) { Text("Addons", color = Color.White) }
        }
        OutlinedTextField(
            value = q, onValueChange = { q = it; if (it.isEmpty()) vm.search("") },
            placeholder = { Text("Buscar") }, singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search(q) }),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        )
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp), color = Red)
        val sr = vm.searchResults
        if (sr != null) {
            if (sr.isEmpty() && !vm.loading) Text("Sin resultados", color = Color.Gray, modifier = Modifier.padding(16.dp))
            LazyVerticalGrid(GridCells.Adaptive(112.dp), contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sr, key = { it.id }) { i -> Poster(i) { vm.openDetail(i) } }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                if (vm.recent.isNotEmpty()) item { MovieRow("Seguir viendo", vm.recent, vm) }
                if (vm.favs.isNotEmpty()) item { MovieRow("Mi lista", vm.favs, vm) }
                items(vm.rows) { r -> MovieRow(r.title, r.items, vm) }
                if (vm.rows.isEmpty() && !vm.loading) item {
                    Text(if (vm.addons.isEmpty()) "No hay addons. Pulsa «Addons» y añade la URL de un manifest.json."
                         else "No se pudieron cargar catálogos.", color = Color.Gray, modifier = Modifier.padding(16.dp))
                }
            }
        }
    }
}

@Composable
fun AddonsScreen(vm: Vm) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("Addons", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(url, { url = it }, label = { Text("URL del manifest.json (https)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = { vm.addAddon(url); url = "" }, colors = ButtonDefaults.buttonColors(containerColor = Red),
            modifier = Modifier.padding(top = 8.dp)) { Text("Añadir") }
        vm.message?.let { Text(it, color = Color.LightGray, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(vm.addons, key = { it.url }) { a ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.name, color = Color.White)
                        Text(a.url, color = Color.Gray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    TextButton(onClick = { vm.removeAddon(a) }) { Text("Quitar", color = Red) }
                }
            }
        }
    }
}

@Composable
fun DetailScreen(vm: Vm) {
    val item = vm.detail ?: return
    var season by remember(item.id) { mutableIntStateOf(-1) }
    val seasons = vm.videos.map { it.season }.distinct().sorted()
    val curSeason = if (season >= 0) season else (seasons.firstOrNull { it > 0 } ?: seasons.firstOrNull() ?: 0)
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Box {
                AsyncImage(model = item.background.ifBlank { item.poster }, contentDescription = null,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(220.dp).background(Card))
                Box(Modifier.matchParentSize().background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, Bg))))
            }
            Column(Modifier.padding(16.dp)) {
                Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                if (item.releaseInfo.isNotBlank()) Text(item.releaseInfo, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Text(item.description, color = Color.LightGray, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (item.type != "series") {
                        Button(onClick = { vm.loadStreams(Video(item.id, item.name, 0, 0), item.type) },
                            colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Reproducir") }
                    }
                    val fav = vm.favs.any { it.id == item.id }
                    OutlinedButton(onClick = { vm.toggleFav(item) }) { Text(if (fav) "Quitar de mi lista" else "Mi lista") }
                }
                if (seasons.size > 1) {
                    LazyRow(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(seasons) { s ->
                            FilterChip(selected = s == curSeason, onClick = { season = s },
                                label = { Text(if (s == 0) "Especiales" else "Temp. $s") })
                        }
                    }
                }
            }
        }
        if (item.type == "series") {
            items(vm.videos.filter { it.season == curSeason }.sortedBy { it.episode }, key = { it.id }) { v ->
                Text("${v.episode}. ${v.title}".trim(), color = Color.White,
                    modifier = Modifier.fillMaxWidth().clickable { vm.loadStreams(v, item.type) }.padding(16.dp, 12.dp))
            }
        }
    }
    val sv = vm.streamsFor
    if (sv != null) {
        AlertDialog(
            onDismissRequest = { vm.streamsFor = null },
            confirmButton = { TextButton(onClick = { vm.streamsFor = null }) { Text("Cerrar") } },
            title = { Text("Fuentes") },
            text = {
                Column {
                    if (vm.streamsLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Red)
                    else if (vm.streams.isEmpty()) Text("No hay fuentes HTTP(S) directas. Torrents y enlaces web no están soportados.")
                    LazyColumn {
                        items(vm.streams) { s ->
                            Text(s.label, color = Color.White, fontSize = 13.sp,
                                modifier = Modifier.fillMaxWidth().clickable { vm.play(s, sv) }.padding(vertical = 10.dp))
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun PlayerScreen(vm: Vm, p: Screen.Player) {
    val act = LocalContext.current as ComponentActivity
    var error by remember { mutableStateOf<String?>(null) }
    var attempt by remember { mutableIntStateOf(0) }

    DisposableEffect(Unit) {
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Un ExoPlayer nuevo por intento: no hereda cabeceras ni estado del anterior.
        key(attempt) {
            val ctx = LocalContext.current
            val exo = remember {
                val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
                    .setDefaultRequestProperties(p.stream.headers)
                ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(http)).build().apply {
                    val b = MediaItem.Builder().setUri(p.stream.url)
                    if (p.stream.fmt == "hls") b.setMimeType(MimeTypes.APPLICATION_M3U8)
                    if (p.stream.fmt == "dash") b.setMimeType(MimeTypes.APPLICATION_MPD)
                    setMediaItem(b.build(), vm.store.resume(p.vid))
                    prepare()
                    playWhenReady = true
                }
            }
            DisposableEffect(exo) {
                val l = object : Player.Listener {
                    override fun onPlayerError(e: PlaybackException) { error = e.errorCodeName }
                }
                exo.addListener(l)
                onDispose {
                    vm.saveResume(p.vid, exo.currentPosition, exo.duration.coerceAtLeast(0))
                    exo.removeListener(l)
                    exo.release()
                }
            }
            AndroidView(factory = { c -> PlayerView(c).apply { player = exo; keepScreenOn = true } },
                modifier = Modifier.fillMaxSize())
        }
        error?.let { e ->
            Column(Modifier.align(Alignment.Center).background(Color(0xCC000000)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Error de reproducción ($e)", color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
                    Button(onClick = { error = null; attempt++ }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Reintentar") }
                    OutlinedButton(onClick = { vm.stack.removeAt(vm.stack.lastIndex) }) { Text("Elegir otra fuente") }
                }
            }
        }
    }
}

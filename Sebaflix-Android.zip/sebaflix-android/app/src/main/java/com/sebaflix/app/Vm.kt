package com.sebaflix.app

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class Vm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var addons by mutableStateOf(listOf<Addon>())
    var rows by mutableStateOf(listOf<Row>())
    var loading by mutableStateOf(false)
    var searchResults by mutableStateOf<List<Item>?>(null)
    val stack = mutableStateListOf<Screen>(Screen.Home)
    var detail by mutableStateOf<Item?>(null)
    var videos by mutableStateOf(listOf<Video>())
    var streams by mutableStateOf(listOf<Stream>())
    var streamsLoading by mutableStateOf(false)
    var streamsFor by mutableStateOf<Video?>(null)
    var message by mutableStateOf<String?>(null)
    var favs by mutableStateOf(store.items("favs"))
    var recent by mutableStateOf(store.items("recent"))

    init { viewModelScope.launch { reloadAddons(); loadHome() } }

    private suspend fun fetchAddon(url: String): Addon? {
        val mf = Net.getJson(url) ?: return null
        if (mf.str("id").isBlank() || mf.optJSONArray("resources") == null) return null
        return Addon(url, url.removeSuffix("/manifest.json"), mf.str("name").ifBlank { "Addon" }, mf)
    }

    private suspend fun reloadAddons() {
        addons = coroutineScope { store.addons().map { async { fetchAddon(it) } }.awaitAll().filterNotNull() }
    }

    fun addAddon(raw: String) {
        val u = normalizeManifestUrl(raw)
        if (u == null) { message = "URL no válida: debe ser https y terminar en /manifest.json"; return }
        if (store.addons().contains(u)) { message = "Ese addon ya está añadido"; return }
        viewModelScope.launch {
            val a = fetchAddon(u)
            if (a == null) { message = "No se pudo leer el manifiesto"; return@launch }
            store.saveAddons(store.addons() + u)
            addons = addons + a
            message = "Añadido: ${a.name}"
            loadHome()
        }
    }

    fun removeAddon(a: Addon) {
        store.saveAddons(store.addons().filter { it != a.url })
        addons = addons.filter { it.url != a.url }
        viewModelScope.launch { loadHome() }
    }

    suspend fun loadHome() {
        loading = true
        val cats = addons.flatMap { a -> a.catalogs().filter { !it.requiredExtra() && it.str("type").isNotBlank() }
            .take(4).map { a to it } }.take(12)
        rows = coroutineScope {
            cats.map { (a, c) ->
                async {
                    val t = c.str("type")
                    val d = Net.getJson("${a.base}/catalog/${enc(t)}/${enc(c.str("id"))}.json")
                    Row("${c.str("name").ifBlank { c.str("id") }} · ${a.name}", parseMetas(d, t))
                }
            }.awaitAll().filter { it.items.isNotEmpty() }
        }
        loading = false
    }

    fun search(q: String) {
        val query = q.trim()
        if (query.isEmpty()) { searchResults = null; return }
        loading = true
        viewModelScope.launch {
            val cats = addons.flatMap { a -> a.catalogs().filter { it.searchable() }.map { a to it } }.take(10)
            val res = coroutineScope {
                cats.map { (a, c) ->
                    async {
                        val t = c.str("type")
                        parseMetas(Net.getJson("${a.base}/catalog/${enc(t)}/${enc(c.str("id"))}/search=${enc(query)}.json"), t)
                    }
                }.awaitAll().flatten()
            }
            searchResults = res.distinctBy { it.id }.take(120)
            loading = false
        }
    }

    fun openDetail(item: Item) {
        detail = item; videos = emptyList(); streams = emptyList(); streamsFor = null
        stack.add(Screen.Detail)
        viewModelScope.launch {
            for (a in addons.filter { it.supports("meta", item.type, item.id) }) {
                val m = Net.getJson("${a.base}/meta/${enc(item.type)}/${enc(item.id)}.json")?.optJSONObject("meta") ?: continue
                detail = item.copy(
                    name = m.str("name").ifBlank { item.name },
                    description = m.str("description").ifBlank { item.description }.take(1000),
                    background = m.str("background").ifBlank { item.background },
                    poster = m.str("poster").ifBlank { item.poster },
                    releaseInfo = m.str("releaseInfo").ifBlank { item.releaseInfo })
                videos = m.optJSONArray("videos").objs().mapNotNull { v ->
                    val id = v.str("id")
                    if (id.isBlank()) null else Video(id, v.str("title").ifBlank { v.str("name") },
                        v.optInt("season", 0), v.optInt("episode", v.optInt("number", 0)))
                }.take(1500)
                break
            }
        }
    }

    fun loadStreams(v: Video, type: String) {
        streamsFor = v; streams = emptyList(); streamsLoading = true
        viewModelScope.launch {
            val all = coroutineScope {
                addons.filter { it.supports("stream", type, v.id) }.map { a ->
                    async { parseStreams(a, Net.getJson("${a.base}/stream/${enc(type)}/${enc(v.id)}.json")) }
                }.awaitAll().flatten()
            }
            streams = all.distinctBy { Triple(it.url, it.fmt, it.headers) }.take(75).sortedBy { fluency(it) }
            streamsLoading = false
        }
    }

    fun play(s: Stream, v: Video) {
        val cur = detail ?: return
        recent = (listOf(cur) + recent.filter { x -> x.id != cur.id }).take(20)
        store.saveItems("recent", recent)
        streamsFor = null
        val title = if (v.id == cur.id) cur.name else "${cur.name} · ${v.title}"
        stack.add(Screen.Player(s, title, v.id))
    }

    fun toggleFav(i: Item) {
        favs = if (favs.any { it.id == i.id }) favs.filter { it.id != i.id } else listOf(i) + favs
        store.saveItems("favs", favs)
    }

    // Solo se guarda al salir del reproductor, nunca periodicamente durante la reproduccion.
    fun saveResume(vid: String, pos: Long, dur: Long) {
        if (dur > 0 && pos > dur * 0.95) store.clearResume(vid)
        else if (pos > 10_000) store.setResume(vid, pos)
    }
}

package com.sebaflix.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Item(val id: String, val type: String, val name: String, val poster: String,
                val background: String, val description: String, val releaseInfo: String)
data class Row(val title: String, val items: List<Item>)
data class Video(val id: String, val title: String, val season: Int, val episode: Int)
data class Stream(val url: String, val label: String, val fmt: String,
                  val headers: Map<String, String>, val rank: Int)
data class Addon(val url: String, val base: String, val name: String, val manifest: JSONObject)

sealed class Screen {
    object Home : Screen()
    object Addons : Screen()
    object Detail : Screen()
    data class Player(val stream: Stream, val title: String, val vid: String) : Screen()
}

fun JSONObject.str(k: String): String { val v = opt(k); return if (v is String) v else "" }
fun JSONArray?.objs(): List<JSONObject> =
    if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }
fun JSONArray?.strs(): List<String> =
    if (this == null) emptyList() else (0 until length()).mapNotNull { opt(it) as? String }

object Net {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()

    suspend fun getJson(url: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                val body = r.body?.string()
                if (!r.isSuccessful || body == null || body.length > 4_000_000) null else JSONObject(body)
            }
        } catch (e: Exception) { null }
    }
}

// ---- Protocolo de addons Stremio (port de AddonProtocol.brs) ----
fun normalizeManifestUrl(raw: String): String? {
    var u = raw.trim()
    if (u.length > 1500) return null
    if (u.lowercase().startsWith("stremio://")) u = "https://" + u.substring(10)
    val l = u.lowercase()
    if (!l.startsWith("https://") || !l.endsWith("/manifest.json")) return null
    if (u.any { it == '?' || it == '#' || it == '\n' || it == '\r' }) return null
    val hp = u.substring(8)
    val slash = hp.indexOf('/')
    if (slash <= 0 || hp.substring(0, slash).contains('@')) return null
    return u
}

fun Addon.supports(res: String, type: String, id: String): Boolean {
    val rs = manifest.optJSONArray("resources") ?: return false
    for (i in 0 until rs.length()) {
        val r = rs.opt(i)
        var name = ""
        var types = manifest.optJSONArray("types")
        var pref = manifest.optJSONArray("idPrefixes")
        if (r is String) name = r
        else if (r is JSONObject) {
            name = r.str("name")
            r.optJSONArray("types")?.let { types = it }
            r.optJSONArray("idPrefixes")?.let { pref = it }
        } else continue
        if (name != res) continue
        val t = types
        val p = pref
        if (t != null && t.strs().none { it == type }) continue
        if (p != null && p.length() > 0 && p.strs().none { id.startsWith(it) }) continue
        return true
    }
    return false
}

fun Addon.catalogs(): List<JSONObject> = manifest.optJSONArray("catalogs").objs()
fun JSONObject.requiredExtra(): Boolean =
    optJSONArray("extra").objs().any { it.optBoolean("isRequired") } ||
        (optJSONArray("extraRequired")?.length() ?: 0) > 0
fun JSONObject.searchable(): Boolean =
    optJSONArray("extra").objs().any { it.str("name") == "search" } ||
        optJSONArray("extraSupported").strs().contains("search")

fun parseMetas(d: JSONObject?, defType: String): List<Item> =
    d?.optJSONArray("metas").objs().mapNotNull { x ->
        val id = x.str("id")
        if (id.isBlank()) null else Item(id, x.str("type").ifBlank { defType }, x.str("name").take(140),
            x.str("poster"), x.str("background"), x.str("description").take(1000), x.str("releaseInfo").take(40))
    }.take(96)

fun enc(s: String) = Uri.encode(s, ":")

fun guessFmt(u: String): String {
    val l = u.lowercase()
    return when {
        l.contains(".m3u8") -> "hls"
        l.contains(".mpd") -> "dash"
        l.contains(".mp4") -> "mp4"
        else -> ""
    }
}

fun qualityRank(t: String): Int {
    val l = t.lowercase()
    return when {
        l.contains("2160") || l.contains("4k") -> 4
        l.contains("1440") -> 3
        l.contains("1080") -> 2
        l.contains("720") -> 1
        l.contains("480") || l.contains("360") -> 0
        else -> -1
    }
}

// Puntuacion de fluidez: menor = mejor (port de sourceFluencyScore)
fun fluency(s: Stream): Int {
    val rk = s.rank
    return when (s.fmt) {
        "hls" -> when (rk) { 1 -> 2; 2 -> 0; 0 -> 7; -1 -> 1; 3 -> 9; else -> 13 }
        "mp4" -> when (rk) { 1 -> 4; 0 -> 5; 2 -> 3; -1 -> 7; 3 -> 11; else -> 14 }
        "dash" -> if (rk >= 3) 15 else 8
        "" -> if (rk >= 3) 17 else 10
        else -> 16
    }
}

fun parseStreams(a: Addon, d: JSONObject?): List<Stream> =
    d?.optJSONArray("streams").objs().mapNotNull { s ->
        val url = s.str("url")
        if (!(url.startsWith("http://") || url.startsWith("https://"))) return@mapNotNull null
        val name = s.str("name"); val title = s.str("title")
        var lbl = a.name
        if (name.isNotBlank()) lbl += " · " + name.replace("\n", " ")
        if (title.isNotBlank()) lbl += " · " + title.replace("\n", " | ")
        lbl = lbl.take(120)
        val hdrs = mutableMapOf<String, String>()
        s.optJSONObject("behaviorHints")?.optJSONObject("proxyHeaders")?.optJSONObject("request")?.let { h ->
            h.keys().forEach { k ->
                val v = h.str(k)
                if (hdrs.size < 12 && k.matches(Regex("[A-Za-z0-9-]{1,64}")) && v.length < 1000 && !v.contains('\n')) hdrs[k] = v
            }
        }
        val fmt = guessFmt(url)
        if (fmt == "") lbl += " [formato por comprobar]"
        val rank = qualityRank("$name $title")
        if (rank >= 4) lbl += " [4K: exige buena conexión]"
        Stream(url, lbl, fmt, hdrs, rank)
    }

// ---- Persistencia (equivalente al registro addonclient) ----
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("addonclient", Context.MODE_PRIVATE)

    fun addons(): List<String> = JSONArray(sp.getString("addons", "[]")).strs()
    fun saveAddons(l: List<String>) = sp.edit().putString("addons", JSONArray(l).toString()).apply()

    private fun itemToJson(i: Item) = JSONObject().put("id", i.id).put("type", i.type).put("name", i.name)
        .put("poster", i.poster).put("background", i.background).put("description", i.description)
        .put("releaseInfo", i.releaseInfo)
    private fun jsonToItem(x: JSONObject) = Item(x.str("id"), x.str("type"), x.str("name"), x.str("poster"),
        x.str("background"), x.str("description"), x.str("releaseInfo"))

    fun items(key: String): List<Item> = JSONArray(sp.getString(key, "[]")).objs().map { jsonToItem(it) }
    fun saveItems(key: String, l: List<Item>) =
        sp.edit().putString(key, JSONArray(l.map { itemToJson(it) }).toString()).apply()

    fun resume(vid: String): Long = sp.getLong("pos:$vid", 0L)
    fun setResume(vid: String, ms: Long) = sp.edit().putLong("pos:$vid", ms).apply()
    fun clearResume(vid: String) = sp.edit().remove("pos:$vid").apply()
}
